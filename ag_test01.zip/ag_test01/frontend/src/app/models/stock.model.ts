export interface Stock {
  id: number;
  code: string;
  name: string;
  currentPrice: number;
  changeAmount: number;
  changePercent: number;
  highPrice: number;
  lowPrice: number;
  volume: number;
  updatedAt: Date;
}
