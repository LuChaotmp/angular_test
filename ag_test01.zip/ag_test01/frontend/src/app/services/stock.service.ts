import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Stock } from '../models/stock.model';

@Injectable({
  providedIn: 'root'
})
export class StockService {
  private apiUrl = 'http://localhost:8080/api/stocks';

  constructor(private http: HttpClient) {}

  getAllStocks(): Observable<Stock[]> {
    return this.http.get<Stock[]>(this.apiUrl);
  }

  getStockById(id: number): Observable<Stock> {
    return this.http.get<Stock>(`${this.apiUrl}/${id}`);
  }

  getStockByCode(code: string): Observable<Stock> {
    return this.http.get<Stock>(`${this.apiUrl}/code/${code}`);
  }

  searchStocks(keyword: string): Observable<Stock[]> {
    return this.http.get<Stock[]>(`${this.apiUrl}/search?q=${encodeURIComponent(keyword)}`);
  }

  filterStocks(type: 'up' | 'down'): Observable<Stock[]> {
    return this.http.get<Stock[]>(`${this.apiUrl}/filter?type=${type}`);
  }
}
