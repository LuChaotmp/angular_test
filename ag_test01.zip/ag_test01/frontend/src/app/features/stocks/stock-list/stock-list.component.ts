import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Stock } from '../../../models/stock.model';
import { StockService } from '../../../services/stock.service';

@Component({
  selector: 'app-stock-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './stock-list.component.html',
  styleUrls: ['./stock-list.component.scss']
})
export class StockListComponent implements OnInit {
  stocks = signal<Stock[]>([]);
  filteredStocks = signal<Stock[]>([]);
  searchKeyword = signal('');
  sortField = signal<'code' | 'changePercent' | 'volume'>('code');
  sortDirection = signal<'asc' | 'desc'>('asc');
  filterType = signal<'all' | 'up' | 'down'>('all');
  isLoading = signal(true);

  constructor(
    private stockService: StockService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadStocks();
  }

  loadStocks(): void {
    this.isLoading.set(true);
    this.stockService.getAllStocks().subscribe({
      next: (data) => {
        this.stocks.set(data);
        this.applyFilters();
        this.isLoading.set(false);
      },
      error: () => {
        this.isLoading.set(false);
      }
    });
  }

  onSearch(): void {
    const keyword = this.searchKeyword();
    if (keyword.trim()) {
      this.stockService.searchStocks(keyword).subscribe({
        next: (data) => {
          this.stocks.set(data);
          this.applyFilters();
        }
      });
    } else {
      this.loadStocks();
    }
  }

  onFilterChange(type: 'all' | 'up' | 'down'): void {
    this.filterType.set(type);
    if (type === 'all') {
      this.loadStocks();
    } else {
      this.stockService.filterStocks(type).subscribe({
        next: (data) => {
          this.stocks.set(data);
          this.applyFilters();
        }
      });
    }
  }

  onSort(field: 'code' | 'changePercent' | 'volume'): void {
    if (this.sortField() === field) {
      this.sortDirection.set(this.sortDirection() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortField.set(field);
      this.sortDirection.set('asc');
    }
    this.applyFilters();
  }

  applyFilters(): void {
    let result = [...this.stocks()];
    
    const field = this.sortField();
    const direction = this.sortDirection();
    
    result.sort((a, b) => {
      let comparison = 0;
      if (field === 'code') {
        comparison = a.code.localeCompare(b.code);
      } else if (field === 'changePercent') {
        comparison = a.changePercent - b.changePercent;
      } else if (field === 'volume') {
        comparison = a.volume - b.volume;
      }
      return direction === 'asc' ? comparison : -comparison;
    });

    this.filteredStocks.set(result);
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  formatPrice(price: number): string {
    return price.toFixed(2);
  }

  formatVolume(volume: number): string {
    if (volume >= 100000000) {
      return (volume / 100000000).toFixed(2) + '亿';
    } else if (volume >= 10000) {
      return (volume / 10000).toFixed(2) + '万';
    }
    return volume.toString();
  }

  getChangeClass(change: number): string {
    if (change > 0) return 'up';
    if (change < 0) return 'down';
    return 'flat';
  }

  getChangeSymbol(change: number): string {
    if (change > 0) return '+';
    return '';
  }
}
