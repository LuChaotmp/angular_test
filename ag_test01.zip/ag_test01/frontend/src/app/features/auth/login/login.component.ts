import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup;
  isLoading = signal(false);
  errorMessage = signal('');

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      account: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      if (!this.loginForm.get('account')?.value || !this.loginForm.get('password')?.value) {
        this.errorMessage.set('请输入账号密码');
        return;
      }
      return;
    }

    this.isLoading.set(true);
    this.errorMessage.set('');

    const loginData = {
      username: this.loginForm.value.account,
      password: this.loginForm.value.password
    };

    this.authService.login(loginData).subscribe({
      next: () => {
        this.router.navigate(['/dashboard']);
      },
      error: (err: any) => {
        this.isLoading.set(false);
        this.errorMessage.set(err.error?.message || '账号或密码错误');
      }
    });
  }

  toHelp(): void {
    console.log('跳转到用户使用说明');
  }

  toUserNotice(): void {
    console.log('跳转到用户须知');
  }
}
