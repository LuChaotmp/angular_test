-- Stock Trading System Database Schema

-- Create database
CREATE DATABASE stock_trading;

-- Connect to database
\c stock_trading;

-- Users table
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);

-- Sample user (password: password123)
INSERT INTO users (username, email, password, role) 
VALUES ('admin', 'admin@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMIN');

INSERT INTO users (username, email, password, role) 
VALUES ('user1', 'user1@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'USER');

-- Stocks table
CREATE TABLE stocks (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    current_price DECIMAL(10,2) DEFAULT 0,
    change_amount DECIMAL(10,2) DEFAULT 0,
    change_percent DECIMAL(10,2) DEFAULT 0,
    high_price DECIMAL(10,2) DEFAULT 0,
    low_price DECIMAL(10,2) DEFAULT 0,
    volume BIGINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_stocks_code ON stocks(code);
CREATE INDEX idx_stocks_name ON stocks(name);

-- Sample stocks data
INSERT INTO stocks (code, name, current_price, change_amount, change_percent, high_price, low_price, volume) VALUES
('600000', '浦发银行', 10.50, 0.25, 2.44, 10.80, 10.20, 85000000),
('600036', '招商银行', 38.90, -0.30, -0.77, 39.50, 38.60, 65000000),
('600519', '贵州茅台', 1680.00, 15.00, 0.90, 1695.00, 1650.00, 12000000),
('601318', '中国平安', 48.50, 0.80, 1.68, 49.00, 47.50, 95000000),
('601398', '工商银行', 5.12, 0.02, 0.39, 5.18, 5.05, 78000000),
('000001', '平安银行', 12.30, -0.15, -1.21, 12.60, 12.10, 55000000),
('000002', '万科A', 8.90, 0.12, 1.37, 9.05, 8.70, 72000000),
('000333', '美的集团', 62.50, 1.20, 1.96, 63.00, 61.00, 45000000),
('000651', '格力电器', 35.80, -0.40, -1.10, 36.50, 35.20, 58000000),
('000858', '五粮液', 148.50, 2.50, 1.71, 150.00, 145.00, 28000000),
('002594', '比亚迪', 268.00, 5.80, 2.21, 272.00, 260.00, 35000000),
('002415', '海康威视', 32.50, 0.50, 1.56, 33.00, 31.80, 42000000),
('300750', '宁德时代', 185.60, -2.40, -1.28, 190.00, 183.50, 48000000),
('300059', '东方财富', 22.80, 0.65, 2.94, 23.20, 22.00, 95000000),
('600276', '恒瑞医药', 52.30, 0.90, 1.75, 53.00, 51.20, 32000000);
