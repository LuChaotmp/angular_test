package com.stock.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "stocks")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 10)
    private String code;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(name = "current_price", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal currentPrice = BigDecimal.ZERO;

    @Column(name = "change_amount", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal changeAmount = BigDecimal.ZERO;

    @Column(name = "change_percent", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal changePercent = BigDecimal.ZERO;

    @Column(name = "high_price", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal highPrice = BigDecimal.ZERO;

    @Column(name = "low_price", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal lowPrice = BigDecimal.ZERO;

    @Column
    @Builder.Default
    private Long volume = 0L;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
