package com.stock.model;

public enum Role {
    USER,
    ADMIN
}
