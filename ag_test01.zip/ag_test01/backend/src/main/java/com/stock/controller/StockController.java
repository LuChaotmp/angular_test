package com.stock.controller;

import com.stock.dto.StockDTO;
import com.stock.service.StockService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stocks")
@RequiredArgsConstructor
public class StockController {
    private final StockService stockService;

    @GetMapping
    public ResponseEntity<List<StockDTO>> getAllStocks() {
        return ResponseEntity.ok(stockService.getAllStocks());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StockDTO> getStockById(@PathVariable Long id) {
        return ResponseEntity.ok(stockService.getStockById(id));
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<StockDTO> getStockByCode(@PathVariable String code) {
        return ResponseEntity.ok(stockService.getStockByCode(code));
    }

    @GetMapping("/search")
    public ResponseEntity<List<StockDTO>> searchStocks(@RequestParam(required = false) String q) {
        return ResponseEntity.ok(stockService.searchStocks(q));
    }

    @GetMapping("/filter")
    public ResponseEntity<List<StockDTO>> filterStocks(@RequestParam(required = false) String type) {
        return ResponseEntity.ok(stockService.getStocksByChangePercent(type));
    }
}
