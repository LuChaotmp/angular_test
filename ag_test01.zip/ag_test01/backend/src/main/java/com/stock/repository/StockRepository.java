package com.stock.repository;

import com.stock.model.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StockRepository extends JpaRepository<Stock, Long> {

    Optional<Stock> findByCode(String code);

    @Query("SELECT s FROM Stock s WHERE s.code LIKE %:keyword% OR s.name LIKE %:keyword%")
    List<Stock> searchByKeyword(@Param("keyword") String keyword);

    List<Stock> findByCodeStartingWith(String codePrefix);
}
