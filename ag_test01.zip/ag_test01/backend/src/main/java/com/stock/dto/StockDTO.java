package com.stock.dto;

import com.stock.model.Stock;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockDTO {
    private Long id;
    private String code;
    private String name;
    private BigDecimal currentPrice;
    private BigDecimal changeAmount;
    private BigDecimal changePercent;
    private BigDecimal highPrice;
    private BigDecimal lowPrice;
    private Long volume;
    private LocalDateTime updatedAt;

    public static StockDTO fromEntity(Stock stock) {
        return StockDTO.builder()
                .id(stock.getId())
                .code(stock.getCode())
                .name(stock.getName())
                .currentPrice(stock.getCurrentPrice())
                .changeAmount(stock.getChangeAmount())
                .changePercent(stock.getChangePercent())
                .highPrice(stock.getHighPrice())
                .lowPrice(stock.getLowPrice())
                .volume(stock.getVolume())
                .updatedAt(stock.getUpdatedAt())
                .build();
    }
}
