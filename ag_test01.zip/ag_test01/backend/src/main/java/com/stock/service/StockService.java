package com.stock.service;

import com.stock.dto.StockDTO;
import com.stock.model.Stock;
import com.stock.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StockService {
    private final StockRepository stockRepository;

    @Transactional(readOnly = true)
    public List<StockDTO> getAllStocks() {
        return stockRepository.findAll().stream()
                .map(StockDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public StockDTO getStockById(Long id) {
        Stock stock = stockRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("股票不存在"));
        return StockDTO.fromEntity(stock);
    }

    @Transactional(readOnly = true)
    public StockDTO getStockByCode(String code) {
        Stock stock = stockRepository.findByCode(code)
                .orElseThrow(() -> new RuntimeException("股票不存在"));
        return StockDTO.fromEntity(stock);
    }

    @Transactional(readOnly = true)
    public List<StockDTO> searchStocks(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllStocks();
        }
        return stockRepository.searchByKeyword(keyword.trim()).stream()
                .map(StockDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<StockDTO> getStocksByChangePercent(String type) {
        List<Stock> stocks = stockRepository.findAll();
        
        if ("up".equals(type)) {
            return stocks.stream()
                    .filter(s -> s.getChangePercent().compareTo(java.math.BigDecimal.ZERO) > 0)
                    .sorted((a, b) -> b.getChangePercent().compareTo(a.getChangePercent()))
                    .map(StockDTO::fromEntity)
                    .collect(Collectors.toList());
        } else if ("down".equals(type)) {
            return stocks.stream()
                    .filter(s -> s.getChangePercent().compareTo(java.math.BigDecimal.ZERO) < 0)
                    .sorted((a, b) -> a.getChangePercent().compareTo(b.getChangePercent()))
                    .map(StockDTO::fromEntity)
                    .collect(Collectors.toList());
        }
        
        return stocks.stream()
                .map(StockDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional
    public StockDTO createStock(Stock stock) {
        return StockDTO.fromEntity(stockRepository.save(stock));
    }

    @Transactional
    public StockDTO updateStock(Long id, Stock stockDetails) {
        Stock stock = stockRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("股票不存在"));
        
        stock.setName(stockDetails.getName());
        stock.setCurrentPrice(stockDetails.getCurrentPrice());
        stock.setChangeAmount(stockDetails.getChangeAmount());
        stock.setChangePercent(stockDetails.getChangePercent());
        stock.setHighPrice(stockDetails.getHighPrice());
        stock.setLowPrice(stockDetails.getLowPrice());
        stock.setVolume(stockDetails.getVolume());
        
        return StockDTO.fromEntity(stockRepository.save(stock));
    }
}
